package com.example.mad2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
CalendarView cv;
ImageButton ib;
int count =0;
Switch s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        s=findViewById(R.id.switch1);
        cv = findViewById(R.id.calendarView2);
        ib = findViewById(R.id.imageButton);

        s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(s.isChecked()==true){
                    cv.setVisibility(View.VISIBLE);
                    Toast.makeText(MainActivity.this,"Switch is checked",Toast.LENGTH_LONG).show();
                }
                else {
                    cv.setVisibility(View.INVISIBLE);
                    Toast.makeText(MainActivity.this,"Switch is un checked",Toast.LENGTH_LONG).show();
                }
            }
        });
        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count++;
                if(count%2==0){
                    ib.setBackgroundResource(R.drawable.ic_launcher_background);
                }
                else {
                    ib.setBackgroundResource(R.drawable.ic_launcher_foreground);
                }
            }
        });


    }
}